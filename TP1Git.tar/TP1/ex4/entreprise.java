public class entreprise {

}
