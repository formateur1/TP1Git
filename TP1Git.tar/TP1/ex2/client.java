/*
* Ceci est notre classe client
*
*/
public class client {

}
