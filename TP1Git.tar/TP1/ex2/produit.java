ma classe produit
