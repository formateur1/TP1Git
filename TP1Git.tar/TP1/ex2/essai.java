ma classe en java
public class essai {

}
